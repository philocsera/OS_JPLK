# 파일 구조 안내 (STRUCTURE)

이 zip의 모든 파일이 무엇이고, 어디에 어떻게 적용하는지 한 페이지로 정리.

---

## 디렉토리 트리

    xv6_swap/
    ├── STRUCTURE.md                ← 이 파일
    │
    ├── kernel/                     [복사] 새로 추가되는 파일
    │   ├── swap.h                  swap 인터페이스 + PTE 인코딩 매크로
    │   └── swap.c                  swap 본체 (slot 관리 + swapout + swapin)
    │
    ├── user/                       [복사] 새로 추가되는 파일
    │   └── swaptest.c              swap 단독 검증 프로그램 (A/B/C 테스트)
    │
    ├── patches/                    [편집 가이드] 기존 xv6 파일 수정 안내
    │   ├── vm.c.patch              uvmunmap/uvmcopy/freewalk/vmfault
    │   ├── syscall_glue.patch      sys_swapout, syscall 등록, proc.h 필드
    │   ├── swaptest_build.patch    swaptest 빌드 등록 (SYS_swapout=28)
    │   │
    │   └── virtio/                 옵션 A: 두 디스크 + 폴링
    │       ├── virtio_disk.c       [복사] virtio_disk.c 전체 교체본
    │       ├── memlayout.h.patch   VIRTIO1, VIRTIO1_IRQ 정의
    │       ├── wiring.patch        plic, trap, defs, main 인터럽트 배선
    │       └── Makefile.patch      swap.img + qemu 옵션
    │
    └── docs/                       문서
        ├── README.md               전체 개요 + 적용 순서 (★ 먼저 읽기)
        ├── STRUCTURE.md → 위로 이동됨 (이 파일이 그 역할)
        ├── JOURNEY.md              설계~버그패치~검증 전체 서사
        ├── CAUTION.md              디버깅 함정 모음 + 진단 체크리스트
        ├── progress.md             단계별 진행도 + 남은 작업
        └── FILE_CLEANUP.md         구버전 파일 정리 내역

---

## 파일을 두 종류로 구분

### [복사] 통째로 추가/교체하는 완성 파일

xv6 트리에 그대로 갖다 놓으면 되는 파일들. 4개.

| 파일 | xv6 트리에서의 위치 | 액션 |
|------|---------------------|------|
| `kernel/swap.h` | `kernel/swap.h` | 신규 추가 |
| `kernel/swap.c` | `kernel/swap.c` | 신규 추가 |
| `user/swaptest.c` | `user/swaptest.c` | 신규 추가 |
| `patches/virtio/virtio_disk.c` | `kernel/virtio_disk.c` | 통째로 교체 (백업 후) |

### [편집 가이드] 기존 파일을 어떻게 고치라는 안내 (.patch)

`.patch` 파일이지만 `git apply`용 정식 unified diff가 **아니다**.
사람(또는 Claude Code)이 읽고 해당 파일을 직접 편집하는 before/after
설명 문서. 5개.

| 가이드 파일 | 편집할 xv6 파일 |
|-------------|----------------|
| `patches/vm.c.patch` | `kernel/vm.c` (uvmunmap/uvmcopy/freewalk/vmfault) |
| `patches/syscall_glue.patch` | `kernel/sysproc.c`, `syscall.h`, `syscall.c`, `defs.h`, `proc.h`, `proc.c`, `user/user.h`, `user/usys.pl` |
| `patches/swaptest_build.patch` | `kernel/syscall.h` (SYS_swapout=28), 위 syscall 등록 파일들, `Makefile` (UPROGS) |
| `patches/virtio/memlayout.h.patch` | `kernel/memlayout.h` (VIRTIO1 정의) |
| `patches/virtio/wiring.patch` | `kernel/plic.c`, `trap.c`, `defs.h`, `main.c` (인터럽트 배선) |
| `patches/virtio/Makefile.patch` | `Makefile` (swap.img + qemu 옵션) |

---

## 통합 순서 (권장)

빌드 의존성을 고려한 순서. 한 단계씩 검증하며 진행하면 디버깅이 쉬움.

### 1단계 — 디스크 인프라 먼저

이게 안 되면 swap 자체가 시작 안 됨.

1. `patches/virtio/memlayout.h.patch` 적용 (VIRTIO1 정의)
2. `kernel/virtio_disk.c`를 `patches/virtio/virtio_disk.c`로 교체
3. `patches/virtio/wiring.patch` 적용 (plic/trap/defs/main)
4. `patches/virtio/Makefile.patch` 적용
5. **검증**: make 빌드, make qemu 부팅, fs 정상(echo/cat) 확인

### 2단계 — swap 본체 추가

6. `kernel/swap.h`, `kernel/swap.c` 추가
7. `patches/vm.c.patch` 적용 (uvm, vmfault에 swap 분기)
8. `patches/syscall_glue.patch` 적용 (sys_swapout, defs, proc.h 필드)
9. **검증**: make 빌드 성공, 부팅 정상

### 3단계 — fork lock 수정 (★ 빠뜨리면 panic)

`patches/syscall_glue.patch`에 포함되어 있지만 특히 중요:
- `kernel/proc.c`의 `kfork()`에서 `uvmcopy` 호출만 좁게
  `release/acquire(&np->lock)`로 감싸기.
- 이게 없으면 swap된 부모를 fork할 때 `panic: acquire`.

### 4단계 — 테스트 프로그램

10. `user/swaptest.c` 추가
11. `patches/swaptest_build.patch` 적용 (SYS_swapout=28, 빌드 등록)
12. **최종 검증**: `make qemu` → `swaptest` → [A][B][C] 전체 PASS

---

## 문서 읽는 순서

1. **`docs/README.md`** — 전체 구조와 통합 순서 (가장 먼저)
2. **`docs/CAUTION.md`** — 빌드/통합 전에 반드시 (함정 미리 피하기)
3. **`docs/JOURNEY.md`** — 왜 이렇게 설계했는지 + 버그 추적 서사
4. **`docs/progress.md`** — 어디까지 됐고 무엇이 남았는지
5. **`docs/FILE_CLEANUP.md`** — 구버전 파일 정리 기록 (참고용)

급할 때는: README → STRUCTURE(이 파일) → CAUTION 만으로도 충분.

---

## 의존성 정보

### 베이스 환경 (검증된 기준)
- MIT xv6-riscv (최신 main 브랜치, VIRTIO MMIO v2)
- 빌드: WSL Ubuntu + `riscv64-linux-gnu-gcc`
- 실행: `qemu-system-riscv64`
- CPU 개수: `CPUS=1` 권장 (디버깅 시 출력 안 섞임)

### 호환성 주의
- xv6-labs 다른 연도 버전은 `virtio_disk.c` 구조가 달라
  `patches/virtio/virtio_disk.c`가 안 맞을 수 있음.
- legacy VIRTIO MMIO v1 (QUEUE_PFN 사용)은 미지원.
  `force-legacy=false` 옵션 필수.

### 이 작업 위에 올라가는 다음 것
swap 메커니즘 자체는 완성. 미완 = LLM 연동:
- `getmemstat`에 swap 통계 노출 (`swap_used_slots()` 함수는 이미 있음)
- `memhint.c`에 `swapout` action 처리 (현재 미존재)
- bridge 프롬프트에 swap 규칙

상세는 `docs/progress.md` "남은 작업" 절 참조.

---

## 현재 검증 상태

```
✅ make 빌드           통과
✅ make qemu 부팅       두 디스크 인식
✅ fs 정상              echo/cat 동작
✅ swaptest [A]         자기 자신 swapout
✅ swaptest [B]         fork된 자식 swapout
✅ swaptest [C]         보호 프로세스(pid 1,2) 거부
✅ 계측 제거 후 재확인   동일하게 전체 PASS
```

swap 메커니즘 자체는 검증 완료. LLM 연동 단계만 미완.

---

## 파일 통계

| 분류 | 개수 | 라인 수 |
|------|------|---------|
| kernel/ (복사) | 2 | ~470 |
| user/ (복사) | 1 | ~190 |
| patches/ (가이드) | 6 | ~880 |
| patches/virtio/virtio_disk.c (복사) | 1 | ~440 |
| docs/ (문서) | 5 | ~720 |
| **합계** | **15** | **~2700** |
