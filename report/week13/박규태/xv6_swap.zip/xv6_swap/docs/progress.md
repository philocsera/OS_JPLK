# Swap 구현 진행 상황

마지막 갱신: swap 메커니즘 검증 완료 시점.

## 한 줄 요약

xv6-riscv에 swap 기능 추가. 커널 측 구현·통합·디버깅·검증까지 전부 완료.
swaptest로 [A][B][C] 전체 PASS 확인. 남은 것은 LLM 연동 단계뿐.

---

## 완료 [완료]

### 설계
- [x] PTE 인코딩 규약 (lazy / swap / invalid 구분)
- [x] 호출 체인 (LLM -> memhint -> syscall -> 커널)
- [x] victim 선택 알고리즘 (단순 + Clock 2종)
- [x] fork/exit 정합성 (uvmcopy, uvmunmap, freewalk)
- [x] 디스크 레이아웃 (slot i -> 블록 i*8)
- [x] 동기화 경계 (lock 안: bitmap / lock 밖: 디스크 I/O)

### 커널 백엔드 (swap.h / swap.c)
- [x] swapinit() — bitmap 초기화
- [x] swap_alloc_slot() / swap_free_slot() — bitmap 슬롯 관리
- [x] swap_write_slot() / swap_read_slot() — 디스크 I/O
- [x] swap_used_slots() / swap_total_slots() — 통계 (getmemstat용, 노출은 아직)
- [x] select_victim_simple() / select_victim_clock() — victim 선택
- [x] swapout_one_page() — Phase 1/2/3 구조 (lock-disk I/O-lock)
- [x] swapout_proc() — pid 검증 + 1페이지 swapout
- [x] swapin_page() — 디스크 read + PTE 복구

### vm.c 패치
- [x] uvmunmap swap PTE 처리 (slot 해제)
- [x] uvmcopy swap slot 복제 (fork)
- [x] freewalk swap PTE 잔존 검출
- [x] vmfault 3분기 (lazy / swap / invalid)

### 디스크 통합 — 옵션 A (두 디스크)
- [x] virtio_disk.c 전면 재작성 — struct disk -> disk[2] 배열
- [x] 폴링 방식 swap I/O — virtio_disk_poll() (sleep 회피)
- [x] memlayout.h — VIRTIO1 / VIRTIO1_IRQ
- [x] plic.c / trap.c — VIRTIO1 인터럽트 배선
- [x] Makefile — swap.img 생성 + qemu 두 번째 디스크 옵션

### 선결 작업 / syscall 연결
- [x] walk() non-static (베이스가 이미 그러함)
- [x] defs.h prototype
- [x] proc.h 필드 (swap_clock_hand 등)
- [x] SYS_swapout = 28 등록 (syscall.h / syscall.c / user.h / usys.pl)
- [x] main.c — virtio_disk_init(1), (2), swapinit() 호출

### 사용자 측 — 테스트
- [x] user/swaptest.c — A(자기 자신) / B(fork 자식) / C(보호 프로세스)
- [x] Makefile UPROGS 등록

### 빌드 / 부팅 / 검증 (WSL + qemu-riscv64)
- [x] make — 전체 컴파일 성공
- [x] make qemu — 두 디스크 인식, 부팅, shell 진입
- [x] fs 정상 — echo/cat, fs.img 무손상
- [x] swaptest 전체 PASS (계측 제거 후 최종 확인)

---

## 이번 작업에서 잡은 버그 (3건, 전부 해결)

### 1. panic: sched locks — 폴링으로 해결
- 원인: swap 디스크 I/O가 sleep을 호출 -> spinlock 보유 중(noff>=2) sleep 불가
- 해결: virtio_disk_rw에서 swap 디바이스(dev=2)는 sleep 대신
  virtio_disk_poll로 used ring 폴링. fs(dev=1)는 sleep 유지.

### 2. uvmcopy lock 보유 중 disk I/O — 좁은 lock 해제로 해결
- 원인: fork의 uvmcopy가 swap 분기에서 디스크 I/O를 하는데,
  allocproc이 준 np->lock을 든 채로 호출됨
- 해결: fork에서 uvmcopy 호출만 좁게 release/acquire로 감쌈.
  np는 USED 상태(RUNNABLE 아님)라 그 구간 lock 해제 안전.
  나머지 np 필드 접근은 lock 보호 그대로.

### 3. panic: acquire — 위 2번 수정으로 함께 해결
- 증상: test_self가 부모를 swap 상태로 만든 뒤, test_child의
  fork->uvmcopy가 swap된 부모를 복제하다 panic
- 진단: 테스트 순서 바꿔(child 먼저) 통과 -> fork/uvmcopy 원인 확정
- 해결: 2번과 동일 수정. 원래 순서(self 먼저)로도 전체 PASS 확인.

### 핵심 교훈
swap이 "전에는 sleep 안 하던 연산"(uvmcopy, copyin/copyout)을
"sleep할 수 있는 연산"으로 바꾼다. 호출자를 하나씩 막는 건 두더지 잡기.
근본 해결은 (a) swap I/O를 폴링으로, (b) 꼭 필요한 곳만 좁게 lock 해제.

---

## 검증 상태 (CAUTION.md 최소 검증 순서)

```
1. 부팅          OK
2. fs 정상       OK
3. swapout 단독  OK   [A] PASS
4. swapin 왕복   OK   [A][B] 패턴 무결성 = 왕복 검증
5. fork/exit     OK   [B] PASS — swap된 부모 fork 포함
6. LLM 통합      미완  <- 아래
```

---

## 남은 작업 [미완] — LLM 연동 (다음 세션)

swap 메커니즘 자체는 끝. 남은 건 LLM 정책이 swap을 쓰게 만드는 것.

### getmemstat 확장
- [ ] getmemstat 구조체에 swap_total, swap_used 필드 추가
- [ ] syscall 구현에서 swap_used_slots()*PGSIZE,
      swap_total_slots()*PGSIZE로 채움
- [ ] (swap.c에 swap_used_slots/swap_total_slots 함수는 이미 있음)
- 목적: LLM이 swap area 잔량을 보고 swapout 제안 여부 판단

### memhint.c — swapout action 처리
- [ ] JSON {"action":"swapout","pid":N} 파싱
- [ ] verifier: pid 1/2 차단, 대상 state 검사, swap enabled 확인
- [ ] swapout(pid) syscall 호출
- 참고: 기존 kill/quota action 처리 패턴을 그대로 복제하면 됨

### bridge 프롬프트
- [ ] "Use swapout only if swap is enabled" 규칙
- [ ] swap 통계를 프롬프트 컨텍스트에 포함

### proclist 확장 (선택)
- [ ] swapout_count / swapin_count 노출 -> LLM thrashing 진단
- 참고: swap.c에 카운터 증가 코드가 주석 처리되어 있음.
  proc.h 필드 추가 후 주석 해제 필요.

### 통합 테스트
- [ ] memstress + LLM이 swapout 제안 -> 실행 -> 결과 확인
- [ ] thrashing 측정

---

## 진척도

```
설계         100%
커널 백엔드   100%  (검증 완료)
디스크 통합   100%  (폴링 포함, 검증 완료)
선결 작업     100%
사용자 측     100%  (swaptest 검증 완료)
LLM 연동        0%  <- 다음 세션
```

---

## 다음 세션 재개 가이드

LLM 연동부터 시작. 진입점 두 개:
1. getmemstat에 swap 통계 노출 (쉬움, 함수는 이미 있음)
2. memhint.c에 swapout action 처리 (기존 action 패턴 복제)

시작 전 확인 필요: memhint.c / bridge 코드의 현재 구조.
기존 action(noop/quota/kill/protect) 처리 방식을 보고 거기에
swapout을 끼워넣는 방식이라, 새 구조를 만드는 게 아님.
