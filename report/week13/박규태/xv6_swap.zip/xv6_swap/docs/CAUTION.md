# Swap 구현 주의사항 (CAUTION)

xv6 트리에 swap 코드를 통합·디버깅할 때 실제로 발목 잡히는 함정들.
"왜 panic이 나지", "왜 파일시스템이 깨졌지" 싶을 때 여기부터 확인.

---

## 1. 디스크 / virtio 관련

### 1.1 QEMU bus 번호를 절대 틀리지 말 것 ★★★

```
-device virtio-blk-device,drive=x1,bus=virtio-mmio-bus.1
                                                       ^^^
```

`.1`을 `.0`으로 쓰면 swap.img가 VIRTIO0(fs.img 자리)에 매핑된다.
그러면 `swap_write_slot`이 **fs.img를 덮어써서 파일시스템이 통째로 파괴**된다.
증상: 부팅은 되는데 `ls`, `cat` 등이 깨지거나 init이 죽음.

### 1.2 swap.img가 없으면 부팅 시 panic

`virtio_disk_init(2)`는 두 번째 디스크가 실제로 붙어 있을 때만 성공한다.
- `swap.img` 파일이 없거나
- QEMUOPTS에 `-drive ...id=x1` / `-device ...bus=virtio-mmio-bus.1`이 빠지면

→ `MAGIC_VALUE` 체크 실패 → `panic("could not find virtio disk")`.

해결: `make` 시 `swap.img`가 의존성에 있는지, `dd` 룰이 도는지 확인.

### 1.3 force-legacy=false 필수

```
-global virtio-mmio.force-legacy=false
```

`virtio_disk.c`는 VIRTIO MMIO **v2 (modern)** 를 가정한다
(QUEUE_DESC_LOW/HIGH 등 분리된 레지스터 사용).
이 옵션이 빠지면 legacy v1으로 떨어져서 `VERSION != 2` panic.

### 1.4 인터럽트 배선 3곳을 모두 고쳐야 함

VIRTIO1_IRQ는 세 곳을 전부 손봐야 동작한다. 하나라도 빠지면:

| 빠진 곳 | 증상 |
|---|---|
| `plicinit()` 우선순위 | swap 디스크 인터럽트가 PLIC에서 무시됨 |
| `plicinithart()` SENABLE | hart가 IRQ 2를 수신 못 함 |
| `devintr()` 분기 | 인터럽트는 오는데 핸들러 호출 안 됨 |

공통 증상: `swap_write_slot`/`swap_read_slot`이 **영원히 sleep** (디스크가
끝났다고 알려줘도 `virtio_disk_intr`이 안 불려서 `b->disk`가 1로 고정).

### 1.5 swap I/O는 fs log를 거치지 않는다

`swap_write_slot`/`swap_read_slot`은 `begin_op`/`end_op` 없이
`bread`/`bwrite`를 직접 호출한다. 이건 의도된 설계다:
- SWAPDEV(=2)는 fs.img와 별개 디바이스 → log와 무관
- swap에 트랜잭션 로깅을 걸면 불필요한 오버헤드 + log 공간 낭비

→ swap 경로에서 `begin_op`를 호출하지 말 것. log full panic의 원인이 됨.

### 1.6 swap 디바이스 I/O는 폴링 방식 (sleep 금지) ★★★

swapin/swapout은 `uvmcopy`, `copyin`/`copyout` 등 **spinlock을 든
커널 경로**에서 호출될 수 있다. xv6의 `sleep`은 `noff==1`을 요구하므로,
lock을 든 채(noff≥2) swap 디스크 I/O가 `sleep`하면 `panic: sched locks`.

→ 해결: `virtio_disk_rw`에서 `b->dev==2`(swap)인 요청은 `sleep` 대신
  `virtio_disk_poll`로 used ring을 폴링한다. fs(dev=1)는 sleep 유지.

주의점:
- 절대 swap 경로에 `sleep`을 다시 넣지 말 것. "uvmcopy에서 panic" →
  "pipe.c에서 panic" → ... 호출자를 하나씩 막는 건 끝이 없다.
  근본 해결은 swap I/O가 sleep을 안 하는 것 하나뿐.
- `virtio_disk_poll`은 lock을 새로 잡지 않는다. 호출자
  (`virtio_disk_rw`)가 이미 `vdisk_lock`을 든 상태로 부른다.
- 폴링 루프는 `vdisk_lock`(spinlock)을 든 채로 돈다. spinlock은
  들고 돌아도 되지만(sleep만 안 하면 됨), 폴링이 길어지면 그 CPU가
  묶인다. swap.img는 QEMU 메모리라 빨라서 실용상 문제 없음.

---

## 2. PTE / 메모리 관련

### 2.1 lazy와 swap을 PTE로 구분 — 매크로를 반드시 통해서

```
swap된 PTE:  V=0, U=1, PPN자리 = slot 번호  → IS_SWAPPED(pte)
lazy PTE:    *pte == 0                       → IS_LAZY(pte)
invalid:     그 외 V=0
```

`*pte == 0` 검사와 `IS_SWAPPED` 검사를 직접 손으로 풀어쓰지 말고
**항상 매크로 사용**. vm.c, trap.c, swap.c가 같은 판단을 해야 한다.
한 곳이라도 다르게 검사하면 lazy 페이지를 swap하려다 `PTE2PA(0)` →
NULL 포인터를 디스크에 쓰는 참사.

### 2.2 swapout: PTE 변경 → TLB flush → kfree 순서 엄수 ★★

```c
*pte = MAKE_SWAP_PTE(slot);   // 1. 먼저 PTE 무효화
sfence_vma();                 // 2. TLB flush
kfree((void*)pa);             // 3. 마지막에 물리 페이지 반환
```

순서를 바꿔 `kfree`를 먼저 하면, 그 사이 다른 CPU나 인터럽트가
**옛 PTE로 free된 페이지에 접근**한다. 메모리 손상 → 재현 어려운 버그.

### 2.3 swapin / swapout 후 sfence_vma 누락 주의

PTE를 직접 수정(`*pte = ...`)했으면 TLB에 옛 매핑이 남아 있다.
`sfence_vma()`를 빠뜨리면:
- swapout 후: 내보낸 페이지에 접근해도 fault가 안 나고 옛 물리주소 사용
- swapin 후: 복구된 페이지에 접근해도 여전히 fault

증상이 "가끔 되고 가끔 안 됨"이라 디버깅이 매우 어렵다.

### 2.4 vmfault는 walk(.., alloc=1)로 호출

lazy 페이지는 leaf page table 자체가 없을 수 있다.
`vmfault`에서 `walk(pt, va, 1)`로 호출해 leaf table 생성을 허용해야 한다.
`alloc=0`으로 하면 lazy 첫 접근 시 `walk`가 0을 반환 → 멀쩡한 접근이
invalid로 처리되어 프로세스가 죽는다.

### 2.5 swapin 시 kalloc 실패 처리

`swapin_page`에서 `kalloc()`이 실패하면 PTE를 swap 상태 그대로 두고
`-1`을 반환한다. 이때 PTE를 건드리면 안 된다 — 디스크의 데이터는
아직 유효하므로, 메모리가 생기면 다시 swapin 할 수 있어야 한다.

단, kalloc 실패가 잦으면 **thrashing 신호**다. progress.md의
swapout_count/swapin_count로 추적할 것.

---

## 3. fork / exit 정합성

### 3.1 uvmcopy: swap된 페이지도 복제해야 함

fork 시 부모에 swap된 페이지가 있으면 자식도 같은 데이터를 가져야 한다.
현재 구현은 **새 슬롯 할당 + 디스크 복사** 방식(슬롯 공유 아님).
→ 자식 슬롯 할당 실패 시 `goto err`로 롤백되는지 확인.

### 3.2 uvmunmap: swap 슬롯 해제 누락 = 슬롯 누수

exit 시 `uvmunmap`이 swap된 PTE를 만나면 `swap_free_slot`을 호출해야 한다.
누락하면 프로세스가 죽어도 슬롯이 해제 안 됨 → 반복되면 swap area가
가득 차서 더 이상 swapout 불가.

### 3.3 freewalk에서 swap PTE panic이 뜨면

`panic("freewalk: swap pte leaked")`가 뜨면 = `uvmunmap`을 거치지 않고
`freewalk`에 도달했다는 뜻. **호출 순서 버그**다.
`proc_freepagetable`이 `uvmunmap` → `uvmfree`(→ freewalk) 순서인지 확인.

---

## 4. syscall / 빌드 관련

### 4.1 walk()의 static 제거 누락

`swap.c`가 `walk()`를 호출한다. `vm.c`에서 `static`을 안 떼면
링크 에러(`undefined reference to walk`). `defs.h`에 prototype 추가도 필수.

### 4.2 SYS_swapout 번호 충돌

`syscall.h`의 `SYS_swapout` 번호가 기존 다른 syscall과 겹치지 않는지 확인.
memhint/quota 등 이미 추가한 syscall이 있다면 그 다음 번호로.

### 4.3 OBJS에 swap.o 추가 누락

Makefile `OBJS`에 `$K/swap.o`를 안 넣으면 `swap.c`가 컴파일조차 안 됨.
링크 단계에서 swap 함수 전부 undefined.

### 4.4 proc.h 필드 추가 후 초기화 누락

`swap_clock_hand`, `swapout_count`, `swapin_count`를 `proc.h`에 추가했으면
`allocproc()`에서 **반드시 0으로 초기화**. 안 하면 쓰레기값 →
Clock 알고리즘이 엉뚱한 va에서 시작하거나 통계가 오염됨.

---

## 5. 정책 / LLM 연동 관련

### 5.1 swapout은 LLM이 pid 단위로만 결정

LLM은 "pid N을 swapout" 까지만 결정한다.
**어느 페이지를 내보낼지는 커널의 victim 선택이 결정**한다.
이 경계를 흐리지 말 것 — LLM이 페이지 테이블을 알 필요가 없고,
그래야 LLM이 init의 핵심 페이지를 직접 지목하는 사고를 막는다.

### 5.2 init / sh 보호는 다중 방어

pid 1/2 차단을 세 군데서 한다:
- `sys_swapout` 진입부
- `swapout_proc` 내부 `is_protected_proc`
- (가능하면) memhint.c verifier

하나로 충분해 보여도 다 두는 게 안전. LLM이 잘못된 pid를 제안해도
커널이 최종 방어선이 된다.

### 5.3 swap 비활성 상태에서 swapout 호출

swap이 빌드에 포함 안 된 환경에서 LLM이 `swapout`을 제안하면 안 된다.
bridge 프롬프트에 "Use swapout only if swap is enabled" 규칙을 넣고,
`getmemstat`에 swap 활성 여부 / `swap_total`을 노출해 LLM이 판단하게 할 것.

### 5.4 thrashing 모니터링

swapout과 swapin이 둘 다 빈번하면 같은 페이지가 왕복하는 thrashing이다.
`swapout_count` / `swapin_count`를 `proclist`에 노출해서 LLM이
"swapout이 역효과를 내고 있다"를 인식하고 정책을 바꿀 수 있게 한다.

---

## 6. 빠른 진단 체크리스트

| 증상 | 의심 지점 |
|---|---|
| `panic: could not find virtio disk` | swap.img 없음 / QEMUOPTS bus 옵션 / force-legacy |
| 부팅 후 `ls`/`cat` 깨짐, init 죽음 | bus 번호 `.1`을 `.0`으로 씀 → fs.img 손상 |
| `panic: sched locks` | swap I/O가 lock 든 채 sleep — virtio_disk_rw 폴링 분기 확인 |
| swapout/swapin이 영원히 멈춤 | 인터럽트 배선 3곳 누락 (fs 경로) / 폴링 루프 미진입 |
| `undefined reference to walk` | vm.c의 static 미제거 / defs.h prototype 누락 |
| `panic: freewalk: swap pte leaked` | uvmunmap → freewalk 호출 순서 버그 |
| `panic: swap_free_slot: double free` | 슬롯을 두 번 해제 (swapin 후 uvmunmap이 또 해제 등) |
| swapout 후 fault 안 남 / 옛 데이터 | sfence_vma 누락 |
| lazy 첫 접근에서 프로세스 죽음 | vmfault가 walk(.., 0)로 호출됨 |
| 멀쩡한 페이지를 swap하다 커널 크래시 | IS_SWAPPED/IS_LAZY 매크로 안 쓰고 직접 검사 |
| swap area가 금방 가득 참 | uvmunmap의 swap_free_slot 누락 = 슬롯 누수 |
| Clock이 엉뚱하게 동작 | swap_clock_hand 초기화 누락 |

---

## 7. 통합 후 최소 검증 순서

1. **부팅** — panic 없이 shell까지 뜨는지 (두 디스크 인식 확인)
2. **fs 정상** — `ls`, `echo hi > f`, `cat f` 동작 (fs.img 안 깨졌는지)
3. **swapout 단독** — `swapout(pid)` 직접 호출하는 테스트 프로그램
4. **swapin 왕복** — swapout 후 그 페이지에 접근 → fault → 복구 → 값 유지 확인
5. **fork/exit** — swap된 페이지를 가진 프로세스를 fork/exit (슬롯 누수 점검)
6. **LLM 통합** — memhint 경유 swapout 제안 → 실행 → 결과 확인
