# 파일 정리 내역 (FILE_CLEANUP)

작업 중 생성된 임시·구버전 파일을 정리한 기록.

## 삭제한 것

### `swap_lazy_distinction/` 폴더 전체 (8개 파일)

```
swap_lazy_distinction/
├── glue.c
├── integration.c
├── swap.c
├── swap.h
├── swap_in.c
├── swap_out.c
├── vm_patches.c
└── vmfault.c
```

**삭제 이유**: swap 초기 작업본. 기능별로 파일을 쪼개 작성했던 1차 결과물인데,
이후 `xv6_swap/` 디렉토리로 통합·재구성하면서 전부 흡수됨. 내용도 낡음
(polling 방식 미반영, virtio 두 디스크 작업 없음). 헷갈림만 유발하므로 삭제.

### 구버전 → 현행 매핑

| 삭제된 옛 파일 | 흡수된 현행 위치 |
|---|---|
| `swap.h` | `xv6_swap/kernel/swap.h` |
| `swap.c` + `swap_in.c` + `swap_out.c` | `xv6_swap/kernel/swap.c` (한 파일로 통합) |
| `vmfault.c` + `vm_patches.c` | `xv6_swap/patches/vm.c.patch` |
| `glue.c` | `xv6_swap/patches/syscall_glue.patch` |
| `integration.c` | `xv6_swap/patches/virtio/*.patch` |

## 현재 유효한 파일 (xv6_swap/)

```
xv6_swap/
├── kernel/                          새로 추가되는 파일
│   ├── swap.h                       인터페이스 + PTE 인코딩 매크로
│   └── swap.c                       slot 관리 + swapout + swapin 본체
├── user/
│   └── swaptest.c                   swap 단독 검증 프로그램 (A/B/C 테스트)
├── patches/                         기존 xv6 파일 수정 가이드
│   ├── vm.c.patch                   uvmunmap/uvmcopy/freewalk/vmfault
│   ├── syscall_glue.patch           sys_swapout/syscall/defs/proc.h
│   ├── swaptest_build.patch         swaptest 빌드 등록 (SYS_swapout=28)
│   └── virtio/                      옵션 A: 두 디스크 지원 + 폴링
│       ├── virtio_disk.c            virtio_disk.c 전체 재작성본 (폴링 포함)
│       ├── memlayout.h.patch        VIRTIO1, VIRTIO1_IRQ 정의
│       ├── wiring.patch             plic/trap/defs/main 인터럽트 배선
│       └── Makefile.patch           swap.img + qemu 옵션
└── docs/
    ├── README.md                    전체 구조 + 적용 순서
    ├── CAUTION.md                   통합·디버깅 함정 모음
    ├── progress.md                  단계별 진행도
    └── FILE_CLEANUP.md              이 파일
```

`xv6_swap.tar.gz` — 위 전체의 압축본.

## 파일 종류 구분

통합 시 다루는 방식이 두 가지다.

### 그대로 복사/교체하는 완성 파일 (`.c` / `.h`)

- `kernel/swap.h`, `kernel/swap.c` → xv6 트리 `kernel/`에 신규 추가
- `user/swaptest.c` → xv6 트리 `user/`에 신규 추가
- `patches/virtio/virtio_disk.c` → 기존 `kernel/virtio_disk.c`를 **통째로 교체**

### before/after 가이드 (`.patch`)

`patches/` 안의 `.patch` 파일들은 `git apply`용 정식 diff가 **아니다**.
기존 파일의 어디를 어떻게 고치라는 before/after 설명 문서다.
사람 또는 Claude Code가 읽고 해당 파일을 직접 편집한다.

- `vm.c.patch` → `kernel/vm.c` 수정 가이드
- `syscall_glue.patch` → syscall 등록 관련 여러 파일 수정 가이드
- `swaptest_build.patch` → swaptest 빌드 등록 가이드
- `virtio/memlayout.h.patch`, `virtio/wiring.patch`, `virtio/Makefile.patch`
  → 각각 해당 파일 수정 가이드

## 본인 PC 측 정리 (참고)

위 삭제는 작업 디렉토리 정리다. 본인 xv6 트리나 다운로드 폴더에
초기 버전(`swap_lazy_distinction` 계열 파일)을 받아뒀다면 그것도 함께
삭제할 것. 최신은 `xv6_swap/` 또는 `xv6_swap.tar.gz` 하나뿐이다.
