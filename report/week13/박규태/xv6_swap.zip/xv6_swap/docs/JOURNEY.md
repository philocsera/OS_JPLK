# xv6 Swap 구현 전체 기록

설계부터 구현, 버그 추적, 검증까지 전 과정의 서사 기록.
"왜 이렇게 했는가"와 "어디서 막혔고 어떻게 풀었는가"를 담는다.
세부 진행도는 progress.md, 함정 모음은 CAUTION.md 참조.

---

## 0. 목표

xv6-riscv에 swap 기능을 추가한다. 물리 메모리가 부족할 때 일부
페이지를 디스크(swap.img)로 내보내고, 다시 접근하면 page fault로
되읽어온다.

설계 배경(memori.md Phase 11): swap은 LLM 메모리 관리 정책이
선택하는 5가지 액션(noop/quota/kill/swapout/protect) 중 하나다.
LLM이 "pid N을 swapout" 까지 결정하고, 어느 페이지를 내보낼지는
커널의 victim 선택이 담당한다. 이 역할 분담이 설계의 핵심이다.

---

## 1. 설계 결정

### 1.1 PTE 인코딩 — lazy / swap / invalid 구분

xv6는 이미 lazy allocation을 쓰기 때문에 PTE의 V=0 상태가
"아직 매핑 안 됨"을 의미한다. swap을 추가하면 V=0이 두 가지 뜻을
갖게 되므로 구분이 필요하다. PTE 비트 패턴으로 해결:

    swap된 PTE:  V=0, U=1, PPN자리 = swap slot 번호
    lazy PTE:    *pte == 0  (전체가 0)
    invalid:     그 외 V=0 PTE

핵심 트릭: lazy는 PTE 자체가 0, swap은 PPN 자리에 slot 번호가
박혀 있다. 이 차이를 IS_SWAPPED / IS_LAZY 매크로로 묶어
vm.c, trap.c, swap.c가 같은 판단을 쓰게 했다.

### 1.2 victim 선택 — 두 가지 모드

- 단순: 첫 user page (va=0 코드 시작점만 회피)
- A bit Clock: PTE_A=0인 페이지를 victim으로, A=1이면 클리어 후 통과

컴파일 플래그 SWAP_VICTIM_CLOCK으로 전환. 실험 비교를 위해
두 모드를 다 남겼다.

공통 보호 규칙: pid 1(init), pid 2(sh), name "init"/"sh"는 제외.
LLM이 잘못된 pid를 제안해도 커널이 최종 방어선이 된다.

### 1.3 디스크 — 별도 디바이스 (옵션 A)

swap.img를 fs.img와 별개의 두 번째 virtio 디스크로 둔다.
- 대안(옵션 B: fs.img 안에 영역 reserve)도 검토했으나,
  buffer cache 경쟁과 성능 측정 오염 때문에 옵션 A 채택.
- slot i는 swap.img 블록 [i*8 .. i*8+8)에 저장 (4KB = 8블록).
- NSWAP=1024 -> 4MB swap area.

### 1.4 동기화 경계

- slot bitmap 접근: swap_pool.lock (spinlock), 짧은 임계구역
- 디스크 I/O: lock 밖에서 수행 (이게 나중에 버그의 핵심이 됨)

---

## 2. 구현 순서

1. swap.h / swap.c — slot 관리 + swapout + swapin 본체
2. vm.c 패치 — uvmunmap/uvmcopy/freewalk에 swap PTE 처리,
   vmfault에 lazy/swap/invalid 3분기
3. virtio_disk.c — 단일 디스크 -> disk[2] 배열로 재작성
4. 인터럽트 배선 — memlayout.h(VIRTIO1), plic.c, trap.c
5. syscall 연결 — SYS_swapout=28, sysproc.c, user stub
6. Makefile — swap.img 생성, qemu 두 번째 디스크 옵션
7. user/swaptest.c — 검증 프로그램

여기까지 빌드·부팅·fs 정상까지 한 번에 통과했다.
가장 위험했던 부분(qemu bus 번호 오류 -> fs.img 손상)도 무사.

---

## 3. 버그 추적 — 세 번의 panic

swap은 한 번에 동작하지 않았다. 세 개의 panic이 연달아 나왔고,
모두 같은 뿌리에서 나왔다.

### 3.1 panic: sched locks

첫 swaptest 실행에서 발생.

증상: swapout 도중 panic: sched locks.

원인: xv6의 sleep은 "지금 든 spinlock이 정확히 1개(noff==1)"를
요구한다. 그런데 swap 디스크 I/O가 sleep을 호출하는데, 그 시점에
다른 spinlock이 잡혀 있어 noff>=2.

근본 이유: swap이 "전에는 sleep 안 하던 연산"을 "sleep할 수 있는
연산"으로 바꿨다. 원래 xv6의 디스크 I/O는 인터럽트+sleep 방식.

해결: virtio_disk_rw에서 swap 디바이스(dev=2) 요청은 sleep 대신
used ring을 직접 폴링(virtio_disk_poll). fs 디바이스(dev=1)는
기존 sleep 방식 유지. 폴링은 sleep을 안 하므로 noff 검사에 안 걸린다.

이때 잘못된 길도 시도했다: panic이 난 호출자(uvmcopy)에 pre-fault를
넣어 막으려 했으나, 이건 (a) lock 잡기 전후 race가 남고
(b) copyin/copyout을 쓰는 다른 호출자에서 재발하는 두더지 잡기였다.
그래서 호출자 패치를 전부 되돌리고 swap I/O 자체(폴링)를 고쳤다.

### 3.2 uvmcopy lock 보유 중 disk I/O

폴링 적용 후 swaptest 테스트 A는 통과. 테스트 B에서 새 panic.

원인: fork()의 uvmcopy가 부모의 swap된 페이지를 복제할 때
디스크 I/O를 한다. 그런데 allocproc()이 준 np->lock을 든 채로
uvmcopy가 호출된다 -> lock 보유 중 디스크 I/O.

원래 xv6에서 uvmcopy는 kalloc+memmove만 했고 둘 다 sleep 안 하니
np->lock을 든 채 호출해도 문제없었다. swap 분기가 추가되면서
uvmcopy가 sleep 가능 연산이 됐다 — 3.1과 같은 패턴.

해결: fork에서 uvmcopy 호출만 좁게 release/acquire로 감쌌다.
np는 아직 USED 상태(RUNNABLE 아님)라 스케줄러가 안 집어가므로
그 구간 lock 해제는 안전. 나머지 np 필드(sz, trapframe, name 등)
접근은 lock 보호 아래 그대로 둬서 lock 규약을 넓게 깨지 않았다.

(첫 시도는 lock 해제 구간이 너무 넓어 np 필드를 lock 없이 건드렸다.
검토를 거쳐 uvmcopy 호출만 감싸도록 좁혔다.)

### 3.3 panic: acquire

테스트 B에서 panic: acquire (이미 든 spinlock 재획득).

진단 과정이 핵심이었다:
1. swap.c의 lock 균형을 전수 검사 -> 모든 에러 경로 release 짝맞음.
   swap.c 자체엔 누수 없음.
2. 코드만으론 위치 특정 불가 -> 계측 도입:
   - swapout_one_page 각 Phase에 진입/종료 마커 printf
   - spinlock.c acquire에 lock 이름 출력
   - swaptest 테스트 순서를 바꿔(child 먼저) 가설 검증
3. 가설: test_self가 부모를 swap 상태로 만들고, test_child의
   fork->uvmcopy가 그 swap된 부모를 복제하다 터진다.
4. 순서 바꿔 실행 -> 통과. 가설 확정.

해결: 3.2의 수정(uvmcopy를 fork lock 밖으로)이 바로 이 문제의
근본 해결이었다. 테스트 순서를 원래대로(self 먼저) 되돌려
재실행 -> 전체 PASS. 회피가 아닌 진짜 해결임을 확인.

### 핵심 교훈

세 panic의 뿌리는 하나다: swap이 sleep 안 하던 연산(디스크 I/O,
uvmcopy, copyin/copyout)을 sleep 가능 연산으로 바꾼다.
- 잘못된 접근: panic 난 호출자를 하나씩 막기 (두더지 잡기, race 잔존)
- 올바른 접근: (a) swap I/O를 폴링으로 근본 해결,
  (b) 꼭 필요한 곳만 좁게 lock 해제

---

## 4. 검증

WSL Ubuntu + riscv64-linux-gnu 툴체인 + qemu-system-riscv64.
MIT xv6-riscv 베이스 (VIRTIO MMIO v2).

- 빌드: 전체 컴파일 성공
- 부팅: 두 디스크 인식, shell 진입, panic 없음
- fs 정상: echo/cat 동작, fs.img 무손상
- swaptest 전체 PASS:
  - [A] 자기 자신 swapout — 16페이지 swapout->swapin 패턴 보존
  - [B] fork된 자식 swapout — swap된 부모 fork 후 자식 패턴 보존
  - [C] 보호 프로세스 — pid 1,2 swapout 거부 확인
- 계측 printf 제거 후 재실행 -> 계측 없이도 전체 PASS 확인

검증 도구 swaptest는 페이지마다 고유 패턴(magic ^ 페이지번호)을
써넣고 swapout 후 다시 읽어 패턴 일치를 검사한다. 패턴이 보존되면
swap I/O와 PTE 복구가 정확하다는 뜻.

---

## 5. 현재 상태와 남은 일

swap 메커니즘 자체는 완성·검증 완료. 커널 측 전부 동작.

남은 것은 LLM 연동뿐:
- getmemstat에 swap 통계(swap_total/swap_used) 노출
  (swap_used_slots/swap_total_slots 함수는 swap.c에 이미 있음)
- memhint.c에 swapout action 처리 (기존 kill/quota 패턴 복제)
- bridge 프롬프트에 swap 규칙
- proclist에 swapout_count/swapin_count (thrashing 진단용, 선택)
- 통합 테스트

상세는 progress.md "남은 작업" 절 참조.

---

## 6. 협업 방식 기록

이 작업은 두 역할로 나뉘어 진행됐다:
- Claude Code: xv6 트리에서 직접 파일 편집, 빌드, 실행, panic 추적
- 채팅 Claude: 설계 검토, 버그의 근본 원인 분석, 수정 방향 제시

3.1의 두더지 잡기에서 벗어난 것이 이 분리 덕분이었다.
Claude Code가 정확한 진단(noff=2, lock 보유 경로)을 제공했고,
채팅 측이 여러 panic을 나란히 놓고 "같은 뿌리"임을 짚어
폴링이라는 근본 해결로 갈 수 있었다.

교훈: 에이전트에게 증상 대응만 맡기지 말고, "이거 전에 본
패턴 아니야?"라고 묻는 검토 루프를 끼우면 두더지 잡기를 피할 수 있다.

---

## 부록: 파일 구성

    xv6_swap/
    kernel/    swap.h, swap.c
    user/      swaptest.c
    patches/   vm.c.patch, syscall_glue.patch, swaptest_build.patch
      virtio/  virtio_disk.c, memlayout.h.patch, wiring.patch, Makefile.patch
    docs/      README.md       — 구조와 적용 순서
               CAUTION.md      — 통합/디버깅 함정 모음
               progress.md     — 단계별 진행도
               JOURNEY.md      — 이 파일 (전체 서사)
               FILE_CLEANUP.md — 파일 정리 내역

.c/.h 파일은 그대로 복사/교체, .patch는 before/after 가이드.
