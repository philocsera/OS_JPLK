# xv6 Swap 구현 — 전체 작업 파일

memori.md (Phase 11) 설계 기반의 xv6-riscv swap 서브시스템 구현체.
MIT xv6-riscv 최신 main (VIRTIO MMIO v2) 기준.

## 디렉토리 구조

```
xv6_swap/
├── kernel/                          새로 추가되는 파일
│   ├── swap.h                       인터페이스 + PTE 인코딩 매크로
│   └── swap.c                       본체: slot 관리 + swapout + swapin
├── patches/                         기존 xv6 파일 수정 가이드
│   ├── vm.c.patch                   uvmunmap/uvmcopy/freewalk/vmfault/walk
│   ├── syscall_glue.patch           sys_swapout/syscall/defs/proc.h/trap
│   └── virtio/                      옵션 A: 두 디스크 지원
│       ├── virtio_disk.c            virtio_disk.c 전체 재작성본
│       ├── memlayout.h.patch        VIRTIO1, VIRTIO1_IRQ 정의
│       ├── wiring.patch             plic/trap/defs/main 인터럽트 배선
│       └── Makefile.patch           swap.img + qemu 옵션
└── docs/
    ├── README.md                    이 파일
    ├── CAUTION.md                   통합·디버깅 시 함정 모음 ★먼저 읽을 것
    ├── JOURNEY.md                   설계~버그패치~검증 전체 서사 기록
    ├── progress.md                  단계별 진행도
    └── FILE_CLEANUP.md              파일 정리 내역

총 11개 파일, 약 1900줄
```

## 설계 요약

### PTE 인코딩 — lazy / swap / invalid 구분

```
swap된 PTE:  V=0,  U=1,  PPN자리 = slot 번호
lazy PTE:    *pte == 0
invalid:     그 외 V=0 PTE
```

### 디스크 매핑 (옵션 A)

```
buf->dev    virtio idx   mmio base     IRQ           용도
1 (ROOTDEV) 0            VIRTIO0       VIRTIO0_IRQ=1  fs.img
2 (SWAPDEV) 1            VIRTIO1       VIRTIO1_IRQ=2  swap.img
```

slot i 는 swap.img의 디스크 블록 [i*8 .. i*8+8) 에 저장 (4KB = 8블록).
NSWAP=1024 → 4MB swap area.

### 호출 체인

```
swapout:
  LLM JSON {"action":"swapout","pid":N}
    → memhint.c (verifier)
    → swapout(pid) syscall
    → sys_swapout → swapout_proc → swapout_one_page
       ├ select_victim()        [단순 / Clock]
       ├ swap_alloc_slot()
       ├ swap_write_slot()
       ├ *pte = MAKE_SWAP_PTE(slot)
       ├ sfence_vma()
       └ kfree(pa)

swapin:
  swap된 va 접근 → page fault (scause 13/15)
    → usertrap → vmfault(pt, va, scause)
       ├ IS_SWAPPED → swapin_page()
       │   ├ kalloc()
       │   ├ swap_read_slot()
       │   ├ *pte = PA2PTE(mem)|perm|PTE_V
       │   ├ swap_free_slot()
       │   └ sfence_vma()
       ├ IS_LAZY    → kalloc + mappages
       └ 그 외      → return -1 (setkilled)
```

## victim 선택 알고리즘

`swap.h`의 `SWAP_VICTIM_CLOCK` 플래그로 전환:
- `0` = 단순 (첫 user page)
- `1` = A bit Clock

Makefile에서 `CFLAGS += -DSWAP_VICTIM_CLOCK=1`로 Clock 빌드.

공통 보호: pid 1(init)/2(sh), name "init"/"sh" 제외.

## 적용 순서

```
1. kernel/swap.h, kernel/swap.c 추가
2. kernel/virtio_disk.c  ← patches/virtio/virtio_disk.c 로 전체 교체
3. kernel/memlayout.h    ← memlayout.h.patch (VIRTIO1 정의)
4. kernel/vm.c           ← vm.c.patch (walk static 제거, uvm*, vmfault)
5. kernel/plic.c, trap.c, defs.h, main.c  ← wiring.patch
6. kernel/sysproc.c, syscall.h, syscall.c  ← syscall_glue.patch
7. kernel/proc.h, proc.c ← syscall_glue.patch (필드 추가/초기화)
8. user/user.h, user/usys.pl  ← swapout stub
9. Makefile              ← virtio/Makefile.patch
```

## 진행 상태

```
설계         ████████████████████ 100%
커널 백엔드   ████████████████████ 100%
디스크 통합   ████████████████████ 100%  (옵션 A 완료)
선결 작업     █████░░░░░░░░░░░░░░░  25%  (가이드만, 적용 필요)
사용자 측     ░░░░░░░░░░░░░░░░░░░░   0%
LLM 연동      ░░░░░░░░░░░░░░░░░░░░   0%
```

다음 작업은 progress.md 참조.
